from __future__ import annotations

import argparse
import gc
import random
import statistics
import sys
import time
import tracemalloc
from pathlib import Path

import matplotlib.pyplot as plt
from lcr import longest_common_repeat

from checker import check_answer

# Experiment parameters


def parse_args():
    parser = argparse.ArgumentParser(description="Run random checker for longest common repeat.")
    parser.add_argument(
        "--base_length",
        "-b",
        type=int,
        default=1000,
        help="Base length for total lengths (default: 1000).",
    )
    parser.add_argument(
        "--repeats",
        "-r",
        type=int,
        default=30,
        help="Number of independent trials per total length (default: 30).",
    )
    parser.add_argument(
        "--k",
        "-k",
        type=int,
        default=-1,
        help="Minimum number of strings a repeat must appear in (default: 2).",
    )
    parser.add_argument(
        "--normal_only",
        "-no",
        action="store_true",
        help="Use normal strings only (no reverse complement or reverse).",
    )
    parser.add_argument(
        "--p",
        "-p",
        type=float,
        default=0.0,
        help="Probability of generating a string with only 'A's (default: 0.0).",
    )
    parser.add_argument(
        "--check",
        "-c",
        action="store_true",
        help="Run the checker to verify correctness of the longest common repeat function.",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose output for debugging.",
    )
    return parser.parse_args()


def distribute_lengths(total, parts):
    base, rem = divmod(total, parts)
    return [base + (1 if i < rem else 0) for i in range(parts)]


def random_dna(alphabet, n, p=0.0):
    if random.random() < p:
        return "".join(random.choice("A") for _ in range(n))
    return "".join(random.choice(alphabet) for _ in range(n))


def run_single_case(
    alphabet,
    total_len,
    num_strings,
    k,
    p=0.0,
    check=False,
    normal_only=False,
    verbose=False,
):
    lens = distribute_lengths(total_len, num_strings)

    strings = [random_dna(alphabet, m, p) for m in lens]
    if k == -1:
        k = random.randint(2, num_strings)

    gc.collect()

    tracemalloc.start()
    start = time.perf_counter()

    ans = longest_common_repeat(strings, k, normal_only=normal_only, verbose=False)

    end_time = time.perf_counter()
    run_time = end_time - start
    _, peak_memory = tracemalloc.get_traced_memory()  # peak memory in bytes
    tracemalloc.stop()

    mem_used = peak_memory / (1024 * 1024)  # Convert to MB

    if check:
        checker_result = check_answer(strings, k, ans, normal_only=normal_only, verbose=verbose)
        if not checker_result:
            raise ValueError(f"[!] Checker failed")
    return run_time, mem_used


def run_benchmark(
    alphabet, total_lengths, num_strings_choices, repeats, k, p, check=False, normal_only=False, verbose=False
):
    rows = []
    print(f"Running {repeats} trials for each Σ|Tᵢ|... (base length: {total_lengths[0]})")
    for total_len in total_lengths:
        results = [
            run_single_case(
                alphabet=alphabet,
                total_len=total_len,
                num_strings=random.choice(num_strings_choices),
                k=k,
                p=p,
                check=check,
                normal_only=normal_only,
                verbose=verbose,
            )
            for _ in range(repeats)
        ]
        times = [result[0] for result in results]
        mems = [result[1] for result in results]
        avg_time = statistics.mean(times)
        std_time = statistics.stdev(times) if repeats > 1 else 0.0
        avg_mem = statistics.mean(mems)
        std_mem = statistics.stdev(mems) if repeats > 1 else 0.0

        rows.append((total_len, avg_time, std_time, avg_mem, std_mem))
        print(
            f"Σ|Tᵢ|={total_len:>7}  avg={avg_time:.6f}s  std={std_time:.6f}s  avg_mem={avg_mem:.2f}MB  std_mem={std_mem:.2f}MB"
        )
    return rows


def save_csv(rows, csv_path):
    with open(csv_path, "w", encoding="utf-8") as f:
        f.write("total_len,avg_time,std_time,avg_mem,std_mem\n")
        for row in rows:
            for i in range(len(row) - 1):
                f.write(f"{row[i]},")
            f.write(f"{row[-1]}\n")
    print(f"CSV saved to {csv_path}")


def plot(file_name, xs, avgs, stds, xlabel="Total length Σ|Tᵢ|", ylabel="Runtime (s)"):
    fig, ax = plt.subplots(figsize=(10, 5))
    plt.rcParams.update({"font.size": 14})

    ax.plot(xs, avgs, marker="o", linewidth=2)
    lower = [a - s for a, s in zip(avgs, stds)]
    upper = [a + s for a, s in zip(avgs, stds)]
    ax.fill_between(xs, lower, upper, alpha=0.25)

    plt.xscale("linear")
    plt.yscale("linear")
    ax.set_xlabel(xlabel, fontsize=14)
    ax.set_ylabel(ylabel, fontsize=14)
    ax.grid(True, which="both", linestyle=":", alpha=0.6)
    fig.tight_layout()
    plt.show()
    plt.savefig(f"{file_name}.png", dpi=300)
    print(f"Plot saved: {file_name}")


if __name__ == "__main__":
    sys.setrecursionlimit(20000)
    print(f"Recursion limit: {sys.getrecursionlimit()}")

    args = parse_args()
    base_len = args.base_length
    repeats = args.repeats
    k = args.k
    p = args.p
    check = args.check
    verbose = args.verbose
    normal_only = args.normal_only

    total_lengths = [base_len * i for i in range(1, 101)]
    num_strings_choices = [2, 3, 4, 5, 6, 7, 8, 9]
    alphabet = "ACGT"
    this_file_name = Path(__file__).name.replace(".py", "")
    save_file_name = f"{this_file_name}{'_no' if normal_only else ''}_B_{base_len}_R_{repeats}_K_{k}_p_{p}"

    if verbose:
        print(f"[+] Running benchmark with parameters:")
        print(f"    Base length: {base_len}")
        print(f"    Repeats: {repeats}")
        print(f"    k: {k}")
        print(f"    p: {p}")
        print(f"    Check: {check}")
        print(f"    Normal only: {normal_only}")
        print(f"    Save file name: {save_file_name}")

    # run benchmark
    data = run_benchmark(
        alphabet=alphabet,
        total_lengths=total_lengths,
        num_strings_choices=num_strings_choices,
        repeats=repeats,
        k=k,
        p=p,
        check=check,
        normal_only=normal_only,
        verbose=verbose,
    )

    # save results to CSV
    save_csv(data, f"{save_file_name}.csv")

    # save plots
    plot(
        f"{save_file_name}_runtime",
        [row[0] for row in data],
        [row[1] for row in data],
        [row[2] for row in data],
    )
    plot(
        f"{save_file_name}_memory",
        [row[0] for row in data],
        [row[3] for row in data],
        [row[4] for row in data],
        ylabel="Memory usage (MB)",
    )

input=$1
output=$2
checkeroutput=$3
./Checker.out ${input} ${output} > ${checkeroutput}

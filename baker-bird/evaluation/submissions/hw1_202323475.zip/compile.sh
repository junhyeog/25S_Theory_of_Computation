g++ -std=c++17 baker-bird.cpp -o BakerBird.out
g++ -std=c++17 checker.cpp -o Checker.out

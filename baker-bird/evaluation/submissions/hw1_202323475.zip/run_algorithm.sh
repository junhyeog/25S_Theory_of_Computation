input=$1
output=$2
./BakerBird.out ${input} > ${output}

g++ baker-bird.cc -o BakerBird.out
g++ checker.cc -o Checker.out
input=$1
output=$2
./decoder.out ${input} ${output}

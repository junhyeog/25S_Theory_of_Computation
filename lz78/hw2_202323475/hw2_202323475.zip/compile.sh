g++ -std=c++17 encoder.cpp -o encoder.out
g++ -std=c++17 decoder.cpp -o decoder.out

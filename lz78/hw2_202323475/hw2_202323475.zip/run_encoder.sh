input=$1
output=$2
./encoder.out ${input} ${output}
